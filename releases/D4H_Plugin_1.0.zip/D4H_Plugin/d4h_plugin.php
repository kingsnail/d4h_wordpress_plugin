<?php 
/*
Plugin Name: D4H Import Incidents
Plugin URI: http://undeadmonkey.org.uk/trunce-plugin/
Description: Utility and helper routines for the Trunce Website
Version: 1.0
Author: Mark Pearce
Author URI: http://undeadmonkey.org.uk/
License: GPLv2
*/
?>
<?php
/* Copyright 2015 Mark Pearce (email: mark@undeadmonkey.org.uk)

   This program is free software; ....

*/
?>
<?php 
require 'include/D4H_get_incidents.php';
require 'include/D4H_plugin_options.php';

register_activation_hook(__FILE__,'D4H_incidents_install');
register_deactivation_hook(__FILE__, 'D4H_incidents_deactivate');

// This shortcode can be used to test and verify the operation of the 
// plugin - add it to the content of a page and it will perform a fetch 
// of the D4H data and output a log as it progresses.
add_shortcode('D4H_get_incidents','D4H_sync_incidents');

// add the admin settings and such
add_action('admin_init', 'UDMD4H_admin_init');

// add the admin options page
add_action('admin_menu', 'UDMD4H_admin_add_page');

function UDMD4H_admin_add_page() {
   add_options_page('D4H Importer Settings', 'D4H Importer Settings', 'manage_options', 'D4H-plugin', 'UDMD4H_options_page');
}

function D4H_incidents_install() {
	// Installation actions...
    
    // Define the array of cofiguration settings for this plug-in
    $UDMD4H_incidents_options = array(
		'API_Key'            => '',           // The API key is the D4H API Access Key
        'Incident_Post_Type' => 'incident',   // Allows incidents to be posted as a custom post type.
                                              // Set this to 'post' if no custom type is being used.
        'Post_Author_ID'     => '1'
	);
    
    update_option('UDMD4H_incidents_options', $UDMD4H_incidents_options);
    
    if (! wp_next_scheduled ( 'D4H_Timed_Sync' )) {
	wp_schedule_event(time(), 'hourly', 'D4H_Timed_Sync');
    }
	
}

add_action('D4H_Timed_Sync', 'do_this_hourly');

function do_this_hourly() {
    $r = D4H_get_incidents();
}

function D4H_incidents_deactivate() {
	wp_clear_scheduled_hook('D4H_Timed_Sync');
	}

function D4H_sync_incidents(){
    echo D4H_get_incidents();
	return;	
}

// Add the 'settings' link to the plug-in entry on the plugins page
add_filter('plugin_action_links_'.plugin_basename(__FILE__), 'UDMD4H_add_plugin_page_settings_link');
function UDMD4H_add_plugin_page_settings_link( $links ) {
	$links[] = '<a href="' .
		admin_url( 'options-general.php?page=D4H-plugin' ) .
		'">' . __('Settings') . '</a>';
	return $links;
}

?>